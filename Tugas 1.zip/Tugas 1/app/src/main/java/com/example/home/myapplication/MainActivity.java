package com.example.home.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView mainList;
    String[] texts = {"Jakarta", "Bandung", "Solo", "Semarang", "Surabaya", "Makasar", "Palembang", "Pekanbaru", "Aceh", "Medan"};
    List<String> ls = Arrays.asList(texts);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_PROGRESS);
        setContentView(R.layout.activity_main);
        mainList = (ListView) findViewById(R.id.listView1);

        MyAdapter adapter = new MyAdapter(ls, getApplicationContext());//new ArrayAdapter(this,android.R.layout.simple_list_item_1,android.R.id.text1,ls); // item ditaruh di adapter ini

        mainList.setAdapter(adapter);//new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,new ArrayList<String>()));

       // jalankan asynctask untuk buka google.com
        new DownloadWebPageTask().execute();

        // event saat item pada listview diklik
        mainList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String s = "List ke- " + String.valueOf(position);//adapter.getItem(position);
                Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(getApplicationContext(), DetailActivity.class);

                // pindah ke activity baru

                intent.putExtra("Urutan", position);
                intent.putExtra("Data ke-", "Yaaa");
                startActivity(intent);

            }
        });


       }

    // Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_base, menu);
        return super.onCreateOptionsMenu(menu);
    }

    private class DownloadWebPageTask extends AsyncTask<String, Void, String> {
        String res = "";
        HttpURLConnection conn;
        @Override
        protected String doInBackground(String... urls) {

            try{
                URL url = new URL("www.google.com");
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                conn.connect();
                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(is,"UTF-8"));

                String data = null;

                while((data = reader.readLine()) != null)
                {
                    res += data + "\n";
                }


            }
            catch (Exception e)
            {
                e.printStackTrace();;

            }



            return res;
        }

        @Override
        protected void onPostExecute(String result) {
           // Tampilkan pesan kalau google udah kebuka
            Toast.makeText(MainActivity.this, "Google was Opened", Toast.LENGTH_SHORT).show();
            //conn.disconnect();
        }



        @Override
        protected void onProgressUpdate(Void... values) {
            //super.onProgressUpdate(values);
        }
    }


    public static class MyAdapter extends BaseAdapter {
        /*
        *    Di kelas ini,dilakukan inflate terhadap item pada list view
        *
        *
        *
        *
        * */

        List<String> data = new ArrayList<String>();
        Context a;

        public MyAdapter(List<String> _data, Context ctx) {
            data = _data;
            a = ctx;
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater li = LayoutInflater.from(a);//from(a);
            convertView = li.inflate(R.layout.list_item, null);
            TextView t1 = (TextView) convertView.findViewById(R.id.textView6);
            TextView t2 = (TextView) convertView.findViewById(R.id.textView2);
            TextView t3 = (TextView) convertView.findViewById(R.id.textView3);
            ImageView im = (ImageView) convertView.findViewById(R.id.imageView);
            im.setImageResource(R.mipmap.ic_launcher);
            t1.setTextSize(18);
            t1.setText(data.get(position));

            //TextView t2 = (TextView) convertView.findViewById(R.id.t2);
            //t2.setTextSize(18);
            //t2.setText("#" + data.get(position) + "#");

            return convertView;
        }
    }
}
